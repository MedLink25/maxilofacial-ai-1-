# 🌒 Atlas Viviente del Rostro: Códice de lo Invisible

🕯️ *Donde la carne, la forma y el alma médica convergen — un oráculo quirúrgico de visiones profundas, nacido del metal y la luz resonante, para trazar los caminos de la curación con el arte sutil de los antiguos sabios.*

---

Este proyecto contiene el backend con FastAPI y la estructura base para desplegar en Render, Fly.io o localmente con Docker.
